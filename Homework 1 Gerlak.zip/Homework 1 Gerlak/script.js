const a = prompt("First number:");
const b = prompt("Second number:");
const c = Number(a) + Number(b);
const result = "Result: " + a + "+" + b + "=" + c;
alert (result);